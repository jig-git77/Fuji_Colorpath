VERSION 5.00
Object = "{D830A729-FC06-11D8-9F5D-000102C87594}#4.1#0"; "thumocx.ocx"
Begin VB.Form frmMain 
   Caption         =   "THUMocx Demo"
   ClientHeight    =   2160
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3885
   LinkTopic       =   "Form1"
   ScaleHeight     =   2160
   ScaleWidth      =   3885
   StartUpPosition =   2  'CenterScreen
   Begin THUMcontrol.THUMocx THUMocx1 
      Left            =   3180
      Top             =   1020
      _ExtentX        =   926
      _ExtentY        =   953
   End
   Begin VB.Frame Frame1 
      Caption         =   "THUM Readings"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1275
      Left            =   600
      TabIndex        =   2
      Top             =   660
      Width           =   2475
      Begin VB.Label Label2 
         Caption         =   "�F"
         Height          =   255
         Index           =   2
         Left            =   1980
         TabIndex        =   11
         Top             =   960
         Width           =   315
      End
      Begin VB.Label Label2 
         Caption         =   "%"
         Height          =   255
         Index           =   1
         Left            =   1980
         TabIndex        =   10
         Top             =   600
         Width           =   315
      End
      Begin VB.Label Label2 
         Caption         =   "�F"
         Height          =   255
         Index           =   0
         Left            =   1980
         TabIndex        =   9
         Top             =   240
         Width           =   315
      End
      Begin VB.Label Label1 
         Caption         =   "Dew Point:"
         Height          =   255
         Index           =   2
         Left            =   120
         TabIndex        =   8
         Top             =   960
         Width           =   795
      End
      Begin VB.Label Label1 
         Caption         =   "RH:"
         Height          =   255
         Index           =   1
         Left            =   120
         TabIndex        =   7
         Top             =   600
         Width           =   615
      End
      Begin VB.Label Label1 
         Caption         =   "Temp:"
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   6
         Top             =   240
         Width           =   615
      End
      Begin VB.Label lblDewpt 
         Caption         =   "Dew Point"
         Height          =   195
         Left            =   1020
         TabIndex        =   5
         Top             =   960
         Width           =   855
      End
      Begin VB.Label lblRH 
         Caption         =   "RH"
         Height          =   255
         Left            =   1020
         TabIndex        =   4
         Top             =   600
         Width           =   675
      End
      Begin VB.Label lblTemp 
         Caption         =   "Temp"
         Height          =   255
         Left            =   1020
         TabIndex        =   3
         Top             =   240
         Width           =   735
      End
   End
   Begin VB.CommandButton cmdReadF 
      Caption         =   "Read �F"
      Height          =   375
      Left            =   2160
      TabIndex        =   1
      Top             =   120
      Width           =   1035
   End
   Begin VB.CommandButton cmdReadC 
      Caption         =   "Read �C"
      Height          =   375
      Left            =   540
      TabIndex        =   0
      Top             =   120
      Width           =   1035
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'THUMocx Demo program
'all code to read from the THUM is in cmdReadC_click and cmdReadF_click
'

Private Sub cmdReadC_Click()
'Reads from THUM and returns values in �C

Dim returnvalue As Integer

'set Temperature Unit
'Valid values are "F" or "C"
'if a non valid value is sent to the control
'the control will reset the Unit to "F"
THUMocx1.Unit = "C"

'tell THUM to take a reading
returnvalue = THUMocx1.Read

'Check to see if reading was successful
If returnvalue = 1 Then
   'successful read
   Else
   'failed read
   msg1 = "Temp Humidity Sensor was not found." & Chr(10) & "Please verifiy it is plugged into a USB port."
   Call MsgBox(msg1, vbExclamation, App.Title)
   Exit Sub
End If

'display values from last reading in labels
lblTemp.Caption = THUMocx1.Temp
lblRH.Caption = THUMocx1.RH
lblDewpt.Caption = THUMocx1.DewPt

'set form labels to the correct units
Label2(0) = "�C"
Label2(1) = "%"
Label2(2) = "�C"

End Sub

Private Sub cmdReadF_Click()
'Reads from THUM and returns values in �F

Dim returnvalue As Integer

'set Temperature Unit
'Valid values are "F" or "C"
'if a non valid value is sent to the control
'the control will reset the Unit to "F"
THUMocx1.Unit = "F"

'tell THUM to take a reading
returnvalue = THUMocx1.Read

'Check to see if reading was successful
If returnvalue = 1 Then
   'successful read
   Else
   'failed read
   msg1 = "Temp Humidity Sensor was not found." & Chr(10) & "Please verifiy it is plugged into a USB port."
   Call MsgBox(msg1, vbExclamation, App.Title)
   Exit Sub
End If

'display values from last reading in labels
lblTemp.Caption = THUMocx1.Temp
lblRH.Caption = THUMocx1.RH
lblDewpt.Caption = THUMocx1.DewPt

'set form labels to the correct units
Label2(0) = "�F"
Label2(1) = "%"
Label2(2) = "�F"

End Sub






Private Sub Form_Load()
lblTemp = ""
lblRH = ""
lblDewpt = ""

End Sub

